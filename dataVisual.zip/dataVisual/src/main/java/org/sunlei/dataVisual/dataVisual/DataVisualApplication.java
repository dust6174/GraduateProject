package org.sunlei.dataVisual.dataVisual;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataVisualApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataVisualApplication.class, args);
	}

}
