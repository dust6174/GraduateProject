package org.sunlei.dataVisual.dataVisual;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataVisualApplicationTests {

	@Test
	void contextLoads() {
	}

}
